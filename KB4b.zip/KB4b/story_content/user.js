function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6cMGT7GzO18":
        Script1();
        break;
      case "6WwNiYZnI6A":
        Script2();
        break;
      case "62uwUVvbYCd":
        Script3();
        break;
      case "6I2bLPfz5oG":
        Script4();
        break;
      case "66zbb9Xfx4S":
        Script5();
        break;
      case "6HfDqUcSWY8":
        Script6();
        break;
      case "5chcz0aznvT":
        Script7();
        break;
      case "64q51RnBQFP":
        Script8();
        break;
      case "5kuZwWIZg1R":
        Script9();
        break;
      case "5hMiK9w39yg":
        Script10();
        break;
      case "6mnpokdVNj9":
        Script11();
        break;
      case "6DPf4MOkv2K":
        Script12();
        break;
      case "6G4Z88brBOT":
        Script13();
        break;
      case "6HpCPzQOvwu":
        Script14();
        break;
      case "5pmcXYism8a":
        Script15();
        break;
      case "5nifIzKkzof":
        Script16();
        break;
      case "5vMwrw1Y4C6":
        Script17();
        break;
      case "6bimhhZNAa6":
        Script18();
        break;
      case "65yyV5Tg7C1":
        Script19();
        break;
      case "5s0hfk239tX":
        Script20();
        break;
      case "5u0Tuhsz2dy":
        Script21();
        break;
      case "5rWVrUD44Gs":
        Script22();
        break;
      case "6h1rXpfZ4op":
        Script23();
        break;
      case "6i5z8HtHy6y":
        Script24();
        break;
      case "6QYgZHL5Vha":
        Script25();
        break;
      case "6KOIJ5i4A4P":
        Script26();
        break;
      case "6C6y7HaBfL0":
        Script27();
        break;
      case "6I4hx72KtXu":
        Script28();
        break;
      case "6RIXcOt3H5d":
        Script29();
        break;
      case "6oivaiAZa1o":
        Script30();
        break;
      case "6gzqHLbH2vP":
        Script31();
        break;
      case "6p2JSem91xb":
        Script32();
        break;
      case "5sx2TbfuA5P":
        Script33();
        break;
      case "6c1vBwjQSsM":
        Script34();
        break;
      case "5ZumwKSqqRJ":
        Script35();
        break;
      case "6hmUVQ1Xuz9":
        Script36();
        break;
      case "6lTpjcseAps":
        Script37();
        break;
      case "6TcsXcmCwVO":
        Script38();
        break;
      case "5ZILEBtRKsu":
        Script39();
        break;
      case "6n2ZQQyrroG":
        Script40();
        break;
      case "6feDra5tuBr":
        Script41();
        break;
      case "6rGBvmU6AuV":
        Script42();
        break;
      case "6kkraWqy4VU":
        Script43();
        break;
      case "67vofoiyYg9":
        Script44();
        break;
      case "6easvwVTsAC":
        Script45();
        break;
      case "5dZ65KgGW0n":
        Script46();
        break;
      case "6i3BcFpPOBX":
        Script47();
        break;
      case "6Xnb8xQ4cHe":
        Script48();
        break;
      case "6etHeXfb9jS":
        Script49();
        break;
      case "6Xs9ad6AEwf":
        Script50();
        break;
      case "6Hq4REEEZPk":
        Script51();
        break;
      case "6OWmxYBBVnp":
        Script52();
        break;
      case "6FmRbwu3kT4":
        Script53();
        break;
      case "6oX9H7hTpw9":
        Script54();
        break;
      case "5o0xv45EobE":
        Script55();
        break;
      case "5mgUBFFAm6j":
        Script56();
        break;
      case "6EE11y18sYl":
        Script57();
        break;
      case "60c4dZaMUz1":
        Script58();
        break;
      case "6Jjyi7A6WH7":
        Script59();
        break;
      case "6quUNTMnynS":
        Script60();
        break;
      case "5k1kfOECrPW":
        Script61();
        break;
      case "6RioPWbCSvr":
        Script62();
        break;
      case "67Wv57qt30K":
        Script63();
        break;
      case "6ARhqcxFpyy":
        Script64();
        break;
      case "6L3mhSz6qQq":
        Script65();
        break;
      case "6UdbyjH3Aim":
        Script66();
        break;
      case "6UAEEuG3Gd9":
        Script67();
        break;
      case "6HHv5edU2tO":
        Script68();
        break;
      case "5s9uIXsvvyN":
        Script69();
        break;
      case "67nGAYys0vn":
        Script70();
        break;
      case "6YC7U68pUMq":
        Script71();
        break;
      case "6Frvzjh9fLf":
        Script72();
        break;
      case "6AZFIgzlu83":
        Script73();
        break;
      case "6M1WzPad4di":
        Script74();
        break;
      case "6K7O1Dunbo1":
        Script75();
        break;
      case "6Ut1XqUsvWl":
        Script76();
        break;
      case "5zQMOWaVH3w":
        Script77();
        break;
      case "6feTm3nM0dF":
        Script78();
        break;
      case "6OrciqDUdVR":
        Script79();
        break;
      case "6pUo7SnFP9Y":
        Script80();
        break;
      case "6FugPZ5GlIk":
        Script81();
        break;
      case "5j8Fn7F9QA9":
        Script82();
        break;
      case "5f9HBPGl3X6":
        Script83();
        break;
      case "6B2L3v5mC9f":
        Script84();
        break;
      case "6mrujFLZkcO":
        Script85();
        break;
      case "5g2OLLLdODW":
        Script86();
        break;
      case "5qulr96vleS":
        Script87();
        break;
      case "6Ya5UcTu9F3":
        Script88();
        break;
      case "61LSibfBjMW":
        Script89();
        break;
      case "5YrFPOAh1gX":
        Script90();
        break;
      case "61XNdpfxAPU":
        Script91();
        break;
      case "5ZJHIcg3wUx":
        Script92();
        break;
      case "6E9ghKwegWr":
        Script93();
        break;
      case "6mb3oAXcghj":
        Script94();
        break;
      case "5WFtMH2dMbs":
        Script95();
        break;
      case "5ZJ8WCOxo5N":
        Script96();
        break;
      case "6DJJOBhqhVv":
        Script97();
        break;
      case "5rJfopq6KJZ":
        Script98();
        break;
      case "5gSAegS0GjF":
        Script99();
        break;
      case "6rNN0TyFX4n":
        Script100();
        break;
      case "6198qosQTJY":
        Script101();
        break;
      case "5aTJo1CY9lc":
        Script102();
        break;
      case "6rG5QPa1lKe":
        Script103();
        break;
      case "66CzQtsG3qX":
        Script104();
        break;
  }
}

function Script1()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

}

function Script2()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script3()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script4()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script5()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script6()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script7()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script8()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script9()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script10()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script11()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script12()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script13()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script14()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script15()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script16()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script17()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script18()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script19()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script20()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script21()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script22()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script23()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script24()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script25()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script26()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script27()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script28()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script29()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script30()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script31()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script32()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script33()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script34()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script35()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script36()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script37()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script38()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script39()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script40()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script41()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script42()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script43()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script44()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script45()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script46()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script47()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script48()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script49()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script50()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script51()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script52()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script53()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script54()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script55()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script56()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script57()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script58()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script59()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script60()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script61()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script62()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script63()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script64()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script65()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script66()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script67()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script68()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script69()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script70()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script71()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script72()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script73()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script74()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script75()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script76()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script77()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script78()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script79()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script80()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script81()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script82()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script83()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script84()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script85()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script86()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script87()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script88()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script89()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script90()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script91()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script92()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script93()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script94()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script95()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script96()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script97()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script98()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script99()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script100()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script101()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script102()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script103()
{
  var player = GetPlayer();
this.Location= player.GetVar("location");

var audio = document.getElementById('bgSong');
audio.src=Location+"Motivational Corporate (medium).mp3";
audio.load();
audio.play();
}

function Script104()
{
  var player = GetPlayer();
this.Location= player.GetVar("location");

var audio = document.getElementById('bgSong');
audio.src=Location+"Motivational Corporate (medium).mp3";
audio.load();
audio.play();
}

