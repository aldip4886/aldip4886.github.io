function ExecuteScript(strId)
{
  switch (strId)
  {
      case "63LoDcs5APR":
        Script1();
        break;
      case "5qPB1Yg8bXM":
        Script2();
        break;
      case "68vgvMLs0rV":
        Script3();
        break;
      case "5y9SIEQSeYZ":
        Script4();
        break;
      case "6RKnGm8QkZM":
        Script5();
        break;
      case "5bo7v26453c":
        Script6();
        break;
      case "5ikLyjXmuZZ":
        Script7();
        break;
      case "6JLdyVjBYSC":
        Script8();
        break;
      case "6Qp539yiRud":
        Script9();
        break;
      case "6Rtn9qRaGhm":
        Script10();
        break;
      case "6MnHl7wwrDg":
        Script11();
        break;
      case "6CXVx8CABNd":
        Script12();
        break;
      case "5uydwyb6oWo":
        Script13();
        break;
      case "6JLVWjWF0gk":
        Script14();
        break;
      case "6oToQNLEFe3":
        Script15();
        break;
      case "6lEjWCqwAfP":
        Script16();
        break;
      case "6jtyyASMrtV":
        Script17();
        break;
      case "6VeVfK4rwpn":
        Script18();
        break;
      case "6EUHPnhxbAt":
        Script19();
        break;
      case "6Ybw8EgNmtV":
        Script20();
        break;
      case "6OEeKDzpwCu":
        Script21();
        break;
      case "6pN2B1rsO8i":
        Script22();
        break;
      case "5h4A231EKSs":
        Script23();
        break;
      case "60SrLPygW9J":
        Script24();
        break;
      case "6p8KbCNN705":
        Script25();
        break;
      case "62QYfTMpR14":
        Script26();
        break;
      case "6DDY910q3Ns":
        Script27();
        break;
      case "6UPttT9lmxS":
        Script28();
        break;
      case "5l79DfIMa0f":
        Script29();
        break;
      case "6mRkQG4hIf9":
        Script30();
        break;
      case "6H6gTJMUhZq":
        Script31();
        break;
      case "6ZvGbJvgxwH":
        Script32();
        break;
      case "5oFdxbZe04d":
        Script33();
        break;
      case "6WXn7o35kmE":
        Script34();
        break;
      case "6EDqRQlyHTn":
        Script35();
        break;
      case "6bFTZJemLej":
        Script36();
        break;
      case "5rAzGORMLtw":
        Script37();
        break;
      case "5ym7Fv8HPve":
        Script38();
        break;
      case "6eB6QKl9BJA":
        Script39();
        break;
      case "6I689GE8AAY":
        Script40();
        break;
      case "6kJRYpJ1FdH":
        Script41();
        break;
      case "6PaOlUyQh7B":
        Script42();
        break;
      case "6G2fMFr1c0x":
        Script43();
        break;
      case "69EcrNfkWPk":
        Script44();
        break;
      case "5kdQlsDLtFT":
        Script45();
        break;
      case "6RTESLQs5tO":
        Script46();
        break;
      case "6opdIpgVrOO":
        Script47();
        break;
      case "6Lh0Oc2bVN3":
        Script48();
        break;
      case "6pY6AN8nOM0":
        Script49();
        break;
      case "6kASBLMDXbw":
        Script50();
        break;
      case "5f4OAo09LVC":
        Script51();
        break;
      case "5tmAZl2rvkW":
        Script52();
        break;
      case "60Xc3eB59M6":
        Script53();
        break;
      case "5WK1zSGVznY":
        Script54();
        break;
      case "6F5ShAPVt1E":
        Script55();
        break;
      case "6iOVWeD2dOQ":
        Script56();
        break;
      case "6YwZ5qJeb3z":
        Script57();
        break;
      case "65Uw5s40FGU":
        Script58();
        break;
      case "6OlL7CtYd1R":
        Script59();
        break;
      case "6hhtmvdpY5j":
        Script60();
        break;
      case "5mVHiwbUu8L":
        Script61();
        break;
      case "6Ww58KSUoNZ":
        Script62();
        break;
      case "620tfiD965K":
        Script63();
        break;
      case "5cDYMoMfHPZ":
        Script64();
        break;
      case "63yY4V2SE7S":
        Script65();
        break;
      case "5zELjqGsFaK":
        Script66();
        break;
      case "61NXamAO8cs":
        Script67();
        break;
      case "6f6o4p5Rbqn":
        Script68();
        break;
      case "5gIuNMxiECn":
        Script69();
        break;
      case "5kFtr7H3dbT":
        Script70();
        break;
      case "6TCRe6S1BgG":
        Script71();
        break;
      case "68PCy1oZGwJ":
        Script72();
        break;
      case "60GRgkzMSpV":
        Script73();
        break;
      case "6TgDOxsLdat":
        Script74();
        break;
      case "6L9QykHxggM":
        Script75();
        break;
      case "6RK8Z5iuusn":
        Script76();
        break;
      case "5ZIY7PLPyqB":
        Script77();
        break;
      case "6Gy7zv1cag7":
        Script78();
        break;
      case "6IYmRk5pDvO":
        Script79();
        break;
      case "5vaIQPRoHba":
        Script80();
        break;
      case "5ZEEIKiauTg":
        Script81();
        break;
      case "6AnZMqGvAp8":
        Script82();
        break;
      case "6O48R1QhZEp":
        Script83();
        break;
      case "6DS3VCvTZ7o":
        Script84();
        break;
      case "6b0Gk1UvE5X":
        Script85();
        break;
      case "5t7pe7kndUM":
        Script86();
        break;
      case "644BOS94Glx":
        Script87();
        break;
      case "5Xbiu2cT7CG":
        Script88();
        break;
      case "6HGrjFpzggR":
        Script89();
        break;
      case "6ZIPisMxZ23":
        Script90();
        break;
      case "5apEsLwxfnE":
        Script91();
        break;
      case "5vrjn5BmeCO":
        Script92();
        break;
      case "6J8TpRg4ZUt":
        Script93();
        break;
      case "6gRAej3NUE4":
        Script94();
        break;
      case "6MZ2wGwV4O7":
        Script95();
        break;
      case "5eYqLJ19HhX":
        Script96();
        break;
      case "6lXDDgouVB7":
        Script97();
        break;
      case "6LTsos13uhv":
        Script98();
        break;
      case "5l7XhykLRMg":
        Script99();
        break;
      case "6mWcSNu1yQY":
        Script100();
        break;
      case "5YMxg7F8su9":
        Script101();
        break;
      case "5olqIpovn0E":
        Script102();
        break;
      case "5vOV2POqvJo":
        Script103();
        break;
      case "6qKvp6vz1xc":
        Script104();
        break;
      case "6MECqxmlYDr":
        Script105();
        break;
      case "6EQV2tMAD0H":
        Script106();
        break;
      case "6miW1noutRq":
        Script107();
        break;
      case "5pDkWt5CGjA":
        Script108();
        break;
      case "6aIubaOwg0B":
        Script109();
        break;
      case "6fSI5Xojlam":
        Script110();
        break;
      case "5s0avv0Nrmz":
        Script111();
        break;
      case "6KOg3COHkkC":
        Script112();
        break;
      case "5gzAnqqN8rh":
        Script113();
        break;
      case "6Aw3dA2e9AU":
        Script114();
        break;
      case "6mbPJG7t03i":
        Script115();
        break;
      case "6jCZ7918t9c":
        Script116();
        break;
      case "5wMoNgKuIvT":
        Script117();
        break;
      case "6f0jduQV7Pm":
        Script118();
        break;
      case "6eHZiTMfml6":
        Script119();
        break;
      case "6L1Vj6KquCU":
        Script120();
        break;
      case "5vgO4L6SfjP":
        Script121();
        break;
      case "5qhNPpRNZK0":
        Script122();
        break;
      case "6WWCztGKx7k":
        Script123();
        break;
      case "6IQAv4dwepJ":
        Script124();
        break;
      case "6rEjzDPo6ON":
        Script125();
        break;
      case "5w5G4olh77G":
        Script126();
        break;
      case "6f2y9vfve7g":
        Script127();
        break;
      case "6IKOyVJaTte":
        Script128();
        break;
      case "6mRVkazFDL4":
        Script129();
        break;
      case "6OXIuiBPuso":
        Script130();
        break;
      case "5h58HU0RHeX":
        Script131();
        break;
      case "6HAjgfCquKm":
        Script132();
        break;
      case "6eFTRd1Iob6":
        Script133();
        break;
      case "6dHWJhw0cgt":
        Script134();
        break;
      case "6FYieFMbBqP":
        Script135();
        break;
      case "5uzeWnzfbYL":
        Script136();
        break;
      case "65m6JvoXJkX":
        Script137();
        break;
      case "6r8yX0KOR8B":
        Script138();
        break;
      case "5hmyMIjuH29":
        Script139();
        break;
      case "67xE8n1YrMG":
        Script140();
        break;
      case "6KHwFiLV7Am":
        Script141();
        break;
      case "5ZtRHuOQ7Ir":
        Script142();
        break;
      case "5kppkiUwrzv":
        Script143();
        break;
      case "6aF3cRXPLHZ":
        Script144();
        break;
      case "6RbnMYoF9q4":
        Script145();
        break;
      case "6B4GXVDX5Hy":
        Script146();
        break;
      case "6TFZ68LYLlM":
        Script147();
        break;
      case "6avpfcK0bmd":
        Script148();
        break;
      case "6VrivxlLqyd":
        Script149();
        break;
      case "5zvwBCE1HgW":
        Script150();
        break;
  }
}

function Script1()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script2()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script3()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script4()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script5()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script6()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script7()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script8()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script9()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script10()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script11()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script12()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

function Script13()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script14()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script15()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script16()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script17()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script18()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script19()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script20()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script21()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script22()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script23()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script24()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script25()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script26()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script27()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script28()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script29()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script30()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script31()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script32()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script33()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script34()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script35()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script36()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script37()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script38()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script39()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script40()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script41()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script42()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script43()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script44()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script45()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script46()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

function Script47()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

}

function Script48()
{
  var player = GetPlayer();
this.Location= player.GetVar("location");

var audio = document.getElementById('bgSong');
audio.src=Location+"musik.mp3";
audio.load();
audio.play();
}

function Script49()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script50()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script51()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script52()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script53()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script54()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script55()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script56()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script57()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script58()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script59()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script60()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script61()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script62()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script63()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script64()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script65()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script66()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script67()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script68()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script69()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script70()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script71()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script72()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script73()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script74()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script75()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script76()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script77()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script78()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script79()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script80()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script81()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script82()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

function Script83()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script84()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script85()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script86()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script87()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script88()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script89()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script90()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script91()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script92()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script93()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script94()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script95()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script96()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script97()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script98()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script99()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script100()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script101()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script102()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script103()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script104()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script105()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script106()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script107()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script108()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script109()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script110()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script111()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script112()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script113()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script114()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script115()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script116()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

function Script117()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script118()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script119()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script120()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script121()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script122()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script123()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script124()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script125()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script126()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script127()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script128()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script129()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script130()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script131()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script132()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script133()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script134()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script135()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script136()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script137()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script138()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script139()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script140()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script141()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script142()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script143()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script144()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script145()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script146()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script147()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script148()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script149()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script150()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

