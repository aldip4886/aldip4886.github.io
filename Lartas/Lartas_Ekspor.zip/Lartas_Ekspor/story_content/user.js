function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6L93Vi1Wx2d":
        Script1();
        break;
      case "5gIpgu7aDgw":
        Script2();
        break;
      case "6f9kb9Uptp3":
        Script3();
        break;
      case "6R0v3eVMx11":
        Script4();
        break;
      case "5mnwUwGZmjN":
        Script5();
        break;
      case "5Z0lrPatsFy":
        Script6();
        break;
      case "6FRQJJPAdsR":
        Script7();
        break;
      case "69CnVEOCtU5":
        Script8();
        break;
      case "6gYnRISi9k4":
        Script9();
        break;
      case "6n6ZEPy74O7":
        Script10();
        break;
      case "5rm5R7MVk2o":
        Script11();
        break;
      case "6IQY53Vnl4g":
        Script12();
        break;
      case "6OVgTJaMIhk":
        Script13();
        break;
      case "6KBlaUOL7Uh":
        Script14();
        break;
      case "5uxRe9i7aUF":
        Script15();
        break;
      case "5a3DWKTjWZp":
        Script16();
        break;
      case "6o9fuqeTqzR":
        Script17();
        break;
      case "6NmW510GMEa":
        Script18();
        break;
      case "68bTEGIsbGu":
        Script19();
        break;
      case "5xEdHmq0P3h":
        Script20();
        break;
      case "6T52ZU7VLsW":
        Script21();
        break;
      case "5z7jERjNGzE":
        Script22();
        break;
      case "5ibXBzFTef1":
        Script23();
        break;
      case "5VDQTjaqzZt":
        Script24();
        break;
      case "5ljWWChC2wR":
        Script25();
        break;
      case "5rpOpVOoYz3":
        Script26();
        break;
      case "5hi2kTPk8Xx":
        Script27();
        break;
      case "6XXhWlqCogu":
        Script28();
        break;
      case "6mmAMd3x6kf":
        Script29();
        break;
      case "6LH80saZj61":
        Script30();
        break;
      case "64kIntdiFfz":
        Script31();
        break;
      case "6UbtLvKOESe":
        Script32();
        break;
      case "6DlrDHEl1E8":
        Script33();
        break;
      case "60AlLf9LowL":
        Script34();
        break;
      case "5mKQLFBvRlf":
        Script35();
        break;
      case "5tJmD3sedRi":
        Script36();
        break;
      case "5XdcApXgWdJ":
        Script37();
        break;
      case "6XYvH48Bm0J":
        Script38();
        break;
      case "5wuAkVqALAj":
        Script39();
        break;
      case "6dz60ga5p2m":
        Script40();
        break;
      case "5dyf50gnu8X":
        Script41();
        break;
      case "67AiaVmsZmK":
        Script42();
        break;
      case "6r0snsh7OUw":
        Script43();
        break;
      case "6nHsKymmT9m":
        Script44();
        break;
      case "6JnzqInB8zE":
        Script45();
        break;
      case "61OYOhDY0aj":
        Script46();
        break;
      case "6JFlogcDJpC":
        Script47();
        break;
      case "6YNU8mNuTWw":
        Script48();
        break;
      case "6VwNL8lN8Gq":
        Script49();
        break;
      case "5iUUNDDnNgF":
        Script50();
        break;
      case "6GnpMPyS0WH":
        Script51();
        break;
      case "69CpIY0xtis":
        Script52();
        break;
      case "60hmpnObbXV":
        Script53();
        break;
      case "5kezEiXixtq":
        Script54();
        break;
      case "5sBQ9KNuZjP":
        Script55();
        break;
      case "5Xw9VO8EOB3":
        Script56();
        break;
      case "66aRFFpBqkt":
        Script57();
        break;
      case "5c5m1pHiDXv":
        Script58();
        break;
      case "6aRTo3By5sa":
        Script59();
        break;
      case "60ElgqhKfXX":
        Script60();
        break;
      case "5elU66zEETR":
        Script61();
        break;
      case "5yeXT3umaDF":
        Script62();
        break;
      case "6DZ8w5G5xuQ":
        Script63();
        break;
      case "6q3csB84ISF":
        Script64();
        break;
      case "6HhZ6yUJRFt":
        Script65();
        break;
      case "680L5MPib7b":
        Script66();
        break;
      case "69U0eQuvRBq":
        Script67();
        break;
      case "6n0hXx6TVOP":
        Script68();
        break;
      case "6Tnu0hF2Gxx":
        Script69();
        break;
      case "6piuhZicur4":
        Script70();
        break;
      case "6qavEoNTP5A":
        Script71();
        break;
      case "6ifKvr2eQf4":
        Script72();
        break;
      case "6H2GB2kvxnp":
        Script73();
        break;
      case "6PK2cNwaHQE":
        Script74();
        break;
      case "6QZ2fLT9fhs":
        Script75();
        break;
      case "5dxebrbxLkL":
        Script76();
        break;
      case "5XzqM1tomkd":
        Script77();
        break;
      case "6BMuP7j22lN":
        Script78();
        break;
      case "5md1AKpX384":
        Script79();
        break;
      case "6fmjmdP9U3Z":
        Script80();
        break;
      case "6Acqw9Ybl5S":
        Script81();
        break;
      case "5cnRASMXC76":
        Script82();
        break;
      case "61noUtQEuRs":
        Script83();
        break;
      case "6CSy2RtIAkQ":
        Script84();
        break;
      case "5bduz4BPKav":
        Script85();
        break;
      case "6PxnCXdjmIX":
        Script86();
        break;
      case "6rg4F5pM96M":
        Script87();
        break;
      case "6QGrJJPNtnd":
        Script88();
        break;
      case "6iY4uWHgyrI":
        Script89();
        break;
      case "6nsRBFbbsf9":
        Script90();
        break;
      case "5i1wc4vWBzp":
        Script91();
        break;
      case "6bm2aqgU6cF":
        Script92();
        break;
      case "6VdW5Wj1Dk3":
        Script93();
        break;
      case "5k8EUErGo5X":
        Script94();
        break;
      case "5gcFmKOKouU":
        Script95();
        break;
      case "6HRXtmIpZ7X":
        Script96();
        break;
      case "5pamvjjOSNx":
        Script97();
        break;
      case "66nn7G9JCHG":
        Script98();
        break;
      case "5d72biwWuzf":
        Script99();
        break;
      case "5vmkaG1QuU4":
        Script100();
        break;
      case "6lQs09Xk8lh":
        Script101();
        break;
      case "6bjlhk2w77X":
        Script102();
        break;
      case "5mTLZFi6Yli":
        Script103();
        break;
      case "5de9v8AF7Hr":
        Script104();
        break;
      case "6lxbzPEjAbn":
        Script105();
        break;
      case "6qzEhFg2i1L":
        Script106();
        break;
      case "6adxCSRGcQH":
        Script107();
        break;
      case "5mmCCgc5k95":
        Script108();
        break;
      case "6J4HPvdBjcN":
        Script109();
        break;
      case "64kNeNP0XxF":
        Script110();
        break;
      case "6QzOgBUQ0vs":
        Script111();
        break;
      case "5ldxluNMVng":
        Script112();
        break;
      case "5WCTKdyZrqp":
        Script113();
        break;
      case "6k65wcOKNdk":
        Script114();
        break;
      case "5XPeTaRricn":
        Script115();
        break;
      case "63WKXltBewK":
        Script116();
        break;
  }
}

function Script1()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script2()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script3()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script4()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script5()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script6()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script7()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script8()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script9()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script10()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script11()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script12()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

function Script13()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script14()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script15()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script16()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script17()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script18()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script19()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script20()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script21()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script22()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script23()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script24()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script25()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script26()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script27()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script28()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script29()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script30()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script31()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script32()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script33()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script34()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script35()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script36()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script37()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script38()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script39()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script40()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script41()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script42()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script43()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script44()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script45()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script46()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

function Script47()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.05;
}

}

function Script48()
{
  var player = GetPlayer();
this.Location= player.GetVar("location");

var audio = document.getElementById('bgSong');
audio.src=Location+"Valentine Guitar.mp3";
audio.load();
audio.play();
}

function Script49()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script50()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script51()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script52()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script53()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script54()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script55()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script56()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script57()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script58()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script59()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script60()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script61()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script62()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script63()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script64()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script65()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script66()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script67()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script68()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script69()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script70()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script71()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script72()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script73()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script74()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script75()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script76()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script77()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script78()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script79()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script80()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script81()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script82()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

function Script83()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script84()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script85()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script86()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script87()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script88()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script89()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script90()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script91()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script92()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script93()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script94()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script95()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script96()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script97()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script98()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script99()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script100()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script101()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script102()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script103()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script104()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script105()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script106()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script107()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script108()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script109()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script110()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script111()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script112()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script113()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script114()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script115()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script116()
{
  var player = GetPlayer();
var storylineVar = player.GetVar("Slider16");
var audio = document.getElementById('bgSong');
audio.volume = storylineVar;
//alert("Your variable is " + storylineVar + ".");
}

