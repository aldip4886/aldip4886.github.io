function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6LNyU9c65Ma":
        Script1();
        break;
      case "6VU0keHv1KM":
        Script2();
        break;
      case "5pHuHN6MFI8":
        Script3();
        break;
      case "6XjecYM9ci2":
        Script4();
        break;
      case "6MPldtaO2hF":
        Script5();
        break;
      case "6khNTPi4sS6":
        Script6();
        break;
      case "63VGJbqgmrN":
        Script7();
        break;
      case "6ak9HjWstsA":
        Script8();
        break;
      case "6Zpfk1VgFMG":
        Script9();
        break;
      case "5YfhXrGwZ2z":
        Script10();
        break;
      case "6PBOkCwNZ0N":
        Script11();
        break;
      case "6OC4nXantZ5":
        Script12();
        break;
      case "5lLZAjorylu":
        Script13();
        break;
      case "5nSY5kl119Q":
        Script14();
        break;
      case "5w1oLoFHNhB":
        Script15();
        break;
      case "6mSksNYCOOk":
        Script16();
        break;
      case "5jhR4svKKqb":
        Script17();
        break;
      case "5xrcAKzcffs":
        Script18();
        break;
      case "5gELVF3SCxs":
        Script19();
        break;
      case "5iBC6IPYKwS":
        Script20();
        break;
      case "6gg3Y7tVboJ":
        Script21();
        break;
      case "63tIDbBe1R7":
        Script22();
        break;
      case "5u7VWUWiXnx":
        Script23();
        break;
      case "5cmcbTcvjkf":
        Script24();
        break;
      case "6paokwr0NBB":
        Script25();
        break;
      case "6aYLSooIvbm":
        Script26();
        break;
      case "5ZK7dpG7oec":
        Script27();
        break;
      case "5uBldn71ucb":
        Script28();
        break;
      case "5qXm8yuLBUC":
        Script29();
        break;
      case "5dmIyHCA0aP":
        Script30();
        break;
      case "61B8mDljcnI":
        Script31();
        break;
      case "5oKxT6hrzBS":
        Script32();
        break;
      case "5ujq37iECR6":
        Script33();
        break;
      case "6Yo2CIOVTYJ":
        Script34();
        break;
      case "6YpF1L1u83F":
        Script35();
        break;
      case "6TE9EJViTWh":
        Script36();
        break;
      case "5tBj9ZI4w2l":
        Script37();
        break;
      case "6kANOpJKDXc":
        Script38();
        break;
      case "6kW9cFLBtiq":
        Script39();
        break;
      case "64BSsK3zrBP":
        Script40();
        break;
      case "6SN62vPwiD3":
        Script41();
        break;
      case "6HDhsFsMYcZ":
        Script42();
        break;
      case "6Fpb6XtViuw":
        Script43();
        break;
      case "6DjXLuMcivA":
        Script44();
        break;
      case "6cx1pJcTzGY":
        Script45();
        break;
      case "5n8RP7M4EJK":
        Script46();
        break;
      case "5adTcgm8mSc":
        Script47();
        break;
      case "61RhakZq45B":
        Script48();
        break;
      case "6ODjq0df5WJ":
        Script49();
        break;
      case "5keAtY8MjfI":
        Script50();
        break;
      case "5iLJDvbUH6T":
        Script51();
        break;
      case "6SZhHP2rzDz":
        Script52();
        break;
      case "5zXrRPjHUw6":
        Script53();
        break;
      case "6L8DFr47oYb":
        Script54();
        break;
      case "5eFGeNWUgk7":
        Script55();
        break;
      case "6bZtphk6gKU":
        Script56();
        break;
      case "6fDMGAO1Zvy":
        Script57();
        break;
      case "6KmXn2ToJRa":
        Script58();
        break;
      case "65QHkIn6rGr":
        Script59();
        break;
      case "5ZD6QIZc6vK":
        Script60();
        break;
      case "5iH5ZsbN3OI":
        Script61();
        break;
      case "61MpYVUDJC0":
        Script62();
        break;
      case "6TR7FapQmfp":
        Script63();
        break;
      case "6kHg7ZiRnk2":
        Script64();
        break;
      case "5uoC4Cksyav":
        Script65();
        break;
      case "6f2GqDEPLHJ":
        Script66();
        break;
      case "66sOK7Z5Lkd":
        Script67();
        break;
      case "6TKfes64njc":
        Script68();
        break;
      case "5X3Ezi9zw3v":
        Script69();
        break;
      case "6hsm0Dk6iPk":
        Script70();
        break;
      case "6TWWTtW1zKR":
        Script71();
        break;
      case "6ATliMLbPRX":
        Script72();
        break;
      case "619p8mnH8bZ":
        Script73();
        break;
      case "6ECeUfujTiU":
        Script74();
        break;
      case "6MUX3PQcXeY":
        Script75();
        break;
      case "5qwKiOzLpi4":
        Script76();
        break;
      case "6eVBbV3KfrB":
        Script77();
        break;
      case "6WS3leevpCb":
        Script78();
        break;
      case "6FQUy17gBOU":
        Script79();
        break;
      case "60wrPcm2zUH":
        Script80();
        break;
      case "6YzQEvEFlGT":
        Script81();
        break;
      case "6ZlaraC1WAM":
        Script82();
        break;
      case "60RaLNQVWGV":
        Script83();
        break;
      case "6j7doPR4lz3":
        Script84();
        break;
      case "5ouqSqCkWxP":
        Script85();
        break;
      case "5oDAVGQlWUO":
        Script86();
        break;
  }
}

function Script1()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.5;
}

}

function Script2()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script3()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script4()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script5()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script6()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script7()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script8()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script9()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script10()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script11()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script12()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script13()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script14()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script15()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script16()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script17()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script18()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script19()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script20()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script21()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script22()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script23()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script24()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script25()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script26()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script27()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script28()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script29()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script30()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script31()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script32()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script33()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script34()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script35()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script36()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script37()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script38()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script39()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script40()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script41()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script42()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script43()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script44()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script45()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script46()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script47()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script48()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script49()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script50()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script51()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script52()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script53()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script54()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script55()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script56()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script57()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script58()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script59()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script60()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script61()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script62()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script63()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script64()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script65()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script66()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script67()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script68()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script69()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script70()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script71()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script72()
{
  //load the scripts dynamically into the head of the document
function add_line() {
    var line = document.createElement("audio");
    var head=document.getElementsByTagName('body')[0];
    line.type = "audio/mp3";
    line.src="";
    line.id="bgSong" ;
	line.autoplay = true;
	line.loop = true;
    head.appendChild(line);
}

//but we only want to add these once!
if(document.getElementById('bgSong')==null){
	add_line();
var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}



}

function Script73()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script74()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.18;
}

function Script75()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.16;
}

function Script76()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.14;
}

function Script77()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.12;
}

function Script78()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.1;
}

function Script79()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.08;
}

function Script80()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.06;
}

function Script81()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.04;
}

function Script82()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.02;
}

function Script83()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0;
}

function Script84()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script85()
{
  if ((document.fullScreenElement && document.fullScreenElement !== null) || 
 (!document.mozFullScreen && !document.webkitIsFullScreen)) {
 if (document.documentElement.requestFullScreen) { 
 document.documentElement.requestFullScreen(); 
 } else if (document.documentElement.mozRequestFullScreen) { 
 document.documentElement.mozRequestFullScreen(); 
 } else if (document.documentElement.webkitRequestFullScreen) { 
 document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT); 
 } 
 } else { 
 if (document.cancelFullScreen) { 
 document.cancelFullScreen(); 
 } else if (document.mozCancelFullScreen) { 
 document.mozCancelFullScreen(); 
 } else if (document.webkitCancelFullScreen) { 
 document.webkitCancelFullScreen(); 
 } 
 }
}

function Script86()
{
  var player = GetPlayer();
this.Location= player.GetVar("location");

var audio = document.getElementById('bgSong');
audio.src=Location+"musik.mp3";
audio.load();
audio.play();
}

